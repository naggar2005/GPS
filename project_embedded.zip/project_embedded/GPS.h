#define pi 3.142857143
