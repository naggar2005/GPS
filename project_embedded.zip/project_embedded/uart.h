#ifndef uart_h
#define uart_h

void uart_init();
char uart_ischar_available();
char uart_getchar();
		#endif